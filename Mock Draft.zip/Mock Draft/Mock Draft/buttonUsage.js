var currTeam;
var nameOfPlayer;
var buttonID;

function changeTeamSelect(name) {
    // .innerHTML allows for us to write text on the screen. This is because this is a js file and not a HTML. 
    // So we need to access HTML properties to do so.
    document.getElementById('teamSelectText').innerHTML = "You picked the " + name;
    const startButton = document.getElementById('startButton');
    startButton.style.display = 'block';
    currTeam = name;
}

function draftPage() {
    // That <div> is the first (and maybe only) element with the class teamsBin, and it is stored in the variable main.
    // [0] accesses the first element in that collection (even if there’s only one element, you still need to use the [0] index.
    // Elements being div, a, p, h1, h2, h3, etc.
    // Since class has only one element "div", we still need to access it with [0].
    // If we had other elements, then we would need to use [1], [2], etc.
    const selectScreen = document.getElementsByClassName('teamsBin')[0];
    const draftScreen = document.getElementsByClassName('draft')[0];
    const draftTeam = document.getElementsByClassName('draft')[1];
    const draftButton = document.getElementsByClassName('draft')[2];
    // For id we do not need to worry about that, no indexing is needed.
    const selectText = document.getElementById("teamSelectText");
    const playerProfile = document.getElementById('openModal')
    document.getElementById('userTeam').style.display = 'block';
    document.getElementById('userTeam').innerHTML += currTeam;
    selectText.style.display = 'none';
    selectScreen.style.display = 'none';
    draftScreen.style.display = 'block';
    draftTeam.style.display = 'block';
    draftButton.style.display = 'block';
    playerProfile.style.display = 'block';
}


// This will add the players to the scrollbar
const draftCon = document.getElementById('draftContainer');

let playersArray = [
    {name: 'Mason Graham', college: 'Michigan', pos: 'DI', rank: 'Rank 1', scout: "With his explosive nature, Graham consistently creates playmaking opportunities. His hands are powerful and purposeful, his leveraged play allows him to stay stout at the point of attack, and his football intelligence really stands out." },
    {name: 'Will Jonson', college: 'Michigan', pos: 'CB', rank: 'Rank 2', scout: "Strong and smart" },
    {name: 'Travis Hunter', college: 'Colorado', pos: 'CB', rank: 'Rank 3', scout: "Small and fast" },
    {name: 'Tetairoa McMillan', college: 'Arizona', pos: 'WR', rank: 'Rank 4', scout: "Very big" },
    {name: 'Malaki Starks', college: 'Georgia', pos: 'S', rank: 'Rank 5'},
    {name: 'Benjamin Morrison', college: 'Notre Dame', pos: 'CB', rank: 'Rank 6'},
    {name: 'Luther Burden III', college: 'Missouri', pos: 'WR', rank: 'Rank 7'},
    {name: 'Will Campbell', college: 'LSU', pos: 'T', rank: 'Rank 8'},
    {name: 'Nic Scourton', college: 'Texas A&M', pos: 'ED', rank: 'Rank 9'},
    {name: 'Mykel Williams', college: 'Georgia', pos: 'ED', rank: 'Rank 10'},
    {name: 'Ashton Jeanty', college: 'Boise State', pos: 'HB', rank: 'Rank 11'},
    {name: 'Kenneth Grant', college: 'Michigan', pos: 'DI', rank: 'Rank 12'},
    {name: 'Abdul Carter', college: 'Penn State', pos: 'ED', rank: 'Rank 13'},
    {name: 'Deone Walker', college: 'Kentucky', pos: 'DI', rank: 'Rank 14'},
    {name: 'Kevin Winston Jr.', college: 'Penn State', pos: 'S', rank: 'Rank 15'},
    {name: 'Quinshon Judkins', college: 'Ohio State', pos: 'HB', rank: 'Rank 16'},
    {name: 'Carson Beck', college: 'Georgia', pos: 'QB', rank: 'Rank 17'},
    {name: 'James Pearce Jr.', college: 'Tennessee', pos: 'ED', rank: 'Rank 18'},
    {name: 'Isaiah Bond', college: 'Texas', pos: 'WR', rank: 'Rank 19'},
    {name: 'Sheduer Sanders', college: 'Colorado', pos: 'QB', rank: 'Rank 20'},
    {name: 'Kelvin Banks Jr.', college: 'Texas', pos: 'T', rank: 'Rank 21'},
    {name: 'Colston Loveland', college: 'Michigan', pos: 'TE', rank: 'Rank 22'},
    {name: 'Dontay Corleone', college: 'Cincinnati', pos: 'DI', rank: 'Rank 23'},
    {name: 'Aireontae Ersery', college: 'Minnesota', pos: 'T', rank: 'Rank 24'},
    {name: 'Emeka Egbuka', college: 'Ohio State', pos: 'WR', rank: 'Rank 25'},
    {name: 'Tacario Davis', college: 'Arizona', pos: 'CB', rank: 'Rank 26'},
    {name: 'Danny Stutsman', college: 'Oklahoma', pos: 'LB', rank: 'Rank 27'},
    {name: 'Harlod Perkins Jr.', college: 'LSU', pos: 'LB', rank: 'Rank 28'},
    {name: 'Shavon Revel', college: 'East Carolina', pos: 'CB', rank: 'Rank 29'},
    {name: 'Elic Ayomanor', college: 'Stanford', pos: 'WR', rank: 'Rank 30'},
    {name: 'Emery Jones Jr.', college: 'LSU', pos: 'T', rank: 'Rank 31'},
    {name: 'Denzel Burke', college: 'Ohio State', pos: 'CB', rank: 'Rank 32'},
    {name: 'Omarion Hampton', college: 'North Carolina', pos: 'HB', rank: 'Rank 33'},
    {name: 'Billy Bowman Jr.', college: 'Oklahoma', pos: 'S', rank: 'Rank 34'},
    {name: 'Princely Umanmielen', college: 'Mississippi', pos: 'ED', rank: 'Rank 35'},
    {name: 'Landon Jackson', college: 'Arkansas', pos: 'ED', rank: 'Rank 36'},
    {name: 'Jack Sawyer', college: 'Ohio State', pos: 'ED', rank: 'Rank 37'},
    {name: 'Ollie Gordon II', college: 'Oklahoma State', pos: 'HB', rank: 'Rank 38'},
    {name: 'Kamari Ramsey', college: 'USC', pos: 'S', rank: 'Rank 39'},
    {name: 'Blake Miller', college: 'Clemson', pos: 'T', rank: 'Rank 40'},
    {name: 'JT Tuimoloau', college: 'Ohio State', pos: 'ED', rank: 'Rank 41'},
    {name: 'Sebastian Castro', college: 'Iowa', pos: 'S', rank: 'Rank 42'},
    {name: 'T.J. Sanders', college: 'South Carolina', pos: 'DI', rank: 'Rank 43'},
    {name: 'Jonah Savaiinaea', college: 'Arizona', pos: 'T', rank: 'Rank 44'},
    {name: 'Jahdae Barron', college: 'Texas', pos: 'CB', rank: 'Rank 45', scout: "Very fast" },
    ]

const numOfPlayerButtons = playersArray.length;


for (let i = 0; i < numOfPlayerButtons; i++) {
    var currPlayer = playersArray[i];
    const button = document.createElement('button');
    const img = document.createElement('img');
    const hr = document.createElement('hr');
    const playerBin = document.createElement('div');
    const playerReport = document.getElementById('reports');
    var nameOfPlayer;
    playerBin.className = 'playerBin';

    img.className = 'playerCollegeImg';
    img.src = "collegeLogos/" + currPlayer.college + ".png"

    // There is a class for the player buttons, but there needs to be id's for each of the players.
    // The id of each player will just be there name.
    // The reason for individual id's is because we need to access reports for each individual player and unique id names does that.
    button.className = 'playersButton';
    nameOfPlayer = button.id = currPlayer.name;
    button.textContent = currPlayer.pos + ": " + currPlayer.name + " -- " + currPlayer.rank;
    
    playerBin.appendChild(img);
    playerBin.appendChild(button);

    // Append the player container to the draft container
    draftCon.appendChild(playerBin);
    draftCon.appendChild(hr);

    // When we click a button, it will grab the unquie name id from the button and display it in the player reports.
    // This will also enable the button to see the player profile.
    document.getElementById(button.id).onclick = function() {
        document.getElementById("openModal").disabled = false;
        // this.id is what allows us to get the button id of the one we click.
        document.getElementById('playerName').innerHTML = this.id;
        playerReport.textContent = currPlayer.scout;
    }

}

const openButton = document.getElementById('openModal');
const closeButton = document.getElementById('closeModal');
const modal = document.getElementById('modal');

openButton.addEventListener("click", () => {
    modal.classList.add('open');
});

closeButton.addEventListener("click", () => {
    modal.classList.remove('open');
});



let teamArray = [
    {name: "Panthers", pick: 1},
    {name: "Patriots", pick: 2},
    {name: "Broncos", pick: 3},
    {name: "Titans", pick: 4},
    {name: "Giants", pick: 5},
    {name: "Commanders", pick: 6},
    {name: "Cardinals", pick: 7},
    {name: "Vikings", pick: 8},
    {name: "Raiders", pick: 9},
    {name: "Seahawks", pick: 10},
    {name: "Saints", pick: 11},
    {name: "Buccaneers", pick: 12},
    {name: "Colts", pick: 13},
    {name: "Steelers", pick: 14},
    {name: "Rams", pick: 15},
    {name: "Jaguars", pick: 16},
    {name: "Browns", pick: 17},
    {name: "Bears", pick: 18},
    {name: "Chargers", pick: 19},
    {name: "Texans", pick: 20},
    {name: "Jets", pick: 21},
    {name: "Falcons", pick: 22},
    {name: "Dolphins", pick: 23},
    {name: "Packers", pick: 24},
    {name: "Cowboys", pick: 25},
    {name: "Eagles", pick: 26},
    {name: "Lions", pick: 27},
    {name: "Bengals", pick: 28},
    {name: "Bills", pick: 29},
    {name: "Ravens", pick: 30},
    {name: "49ers", pick: 31},
    {name: "Chiefs", pick: 32},
]

// This will add the teams to the scrollbar
const teamCon = document.getElementById('teamContainer');

// This will iterate through all the teams and add them into the scrollbar
for (let i = 0; i < 32; i++) {
    var currTeam = teamArray[i];
    const head = document.createElement('h2');
    const img = document.createElement('img');
    const hr = document.createElement('hr');
    const teamBox = document.createElement('div');
    var team;
    teamBox.className = 'teamBox';

    img.className = 'teamImg';
    img.src = 'logos/' + currTeam.name + '.png';

    head.className = 'teamText';
    head.id = currTeam.name;
    head.textContent = 'Upcoming';

    teamBox.appendChild(img);
    teamBox.appendChild(head);

    teamCon.appendChild(teamBox);
    teamCon.appendChild(hr);

    // 
    var indexOfTeam = 0
    var teamOnTheClock = document.getElementById(teamArray[indexOfTeam].name);
    teamOnTheClock.textContent = 'On the clock';

    // Trying to remove the button, img, name, etc from draft board. DOES NOT WORK.
    document.getElementById("draftButton").onclick = function() {
        const playerToRemove = document.querySelector('.playersButton.active');
        const draftedPlayerName = document.querySelector('.playersButton.active').id;
        
        // If we selected a player when we click the draft button
        if (playerToRemove) {
            const playerBin = playerToRemove.parentElement; // Access parent element (playerBin)
            const hr = playerBin.nextElementSibling; // Get the <hr> element following the player bin
            draftCon.removeChild(playerBin);
            draftCon.removeChild(hr);  // Remove hr if needed
        }

        // If we click the draft button and we have a team on the clock
        if (teamOnTheClock) {
            // Replace "On the clock" with the player name
            teamOnTheClock.textContent = draftedPlayerName; 
            // Increament to the next team
            indexOfTeam++;
            // Update the team that is on the clock, and add the text 'On the clock'
            teamOnTheClock = document.getElementById(teamArray[indexOfTeam].name);
            teamOnTheClock.textContent = 'On the clock'
        }
    }
}


// document.getElementById("draftButton").onclick = function() {
//     const draftedPlayerName = document.querySelector('.playersButton.active').id;
//     const teamOnTheClock = document.getElementById('onClock'); // Assuming you have an "onClock" class for the current team
//     if (teamOnTheClock) {
//         teamOnTheClock.textContent = draftedPlayerName; // Replace "On the clock" with the player name
//         teamOnTheClock.classList.remove('onClock'); // Remove onClock class after drafting
//     }
// };

// This removes the players from the scrollbar. ASK CHAT HOW IT WORKS.
// Function to handle button clicks and manage active states
const buttons = document.querySelectorAll('.playersButton');

buttons.forEach(button => {
    button.addEventListener('click', function() {
        // Remove active class from all buttons
        buttons.forEach(btn => btn.classList.remove('active'));

        // Add active class to the clicked button
        this.classList.add('active');
    });
});



