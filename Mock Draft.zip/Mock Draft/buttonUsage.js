var currTeam;

function changeTeamSelect(name) {
    // .innerHTML allows for us to write text on the screen. This is because this is a js file and not a HTML. 
    // So we need to access HTML properties to do so.
    document.getElementById('teamSelectText').innerHTML = "You picked the " + name;
    const startButton = document.getElementById('startButton');
    startButton.style.display = 'block';
    currTeam = name;
}

function draftPage() {
    // That <div> is the first (and maybe only) element with the class teamsBin, and it is stored in the variable main.
    // [0] accesses the first element in that collection (even if there’s only one element, you still need to use the [0] index.
    // Elements being div, a, p, h1, h2, h3, etc.
    // Since class has only one element "div", we still need to access it with [0].
    // If we had other elements, then we would need to use [1], [2], etc.
    const selectScreen = document.getElementsByClassName('teamsBin')[0];
    const draftScreen = document.getElementsByClassName('draft')[0];
    const draftButtonAndTeams = document.getElementsByClassName('draft')[1];
    // For id we do not need to worry about that, no indexing is needed.
    const selectText = document.getElementById("teamSelectText");
    document.getElementById('userTeam').style.display = 'block';
    document.getElementById('userTeam').innerHTML += currTeam;
    selectText.style.display = 'none';
    selectScreen.style.display = 'none';
    draftScreen.style.display = 'block';
    draftButtonAndTeams.style.display = 'block';
}

function playerProfile() {
    const button = document.getElementById('profile')
    button.style.display = 'block';
}

// This will add the players to the scrollbar
const draftCon = document.getElementById('draftContainer');

let playersArray = [
    {name: 'Mason Graham', college: 'Michigan', pos: 'DI', rank: 'Rank 1'},
    {name: 'Will Jonson', college: 'Michigan', pos: 'CB', rank: 'Rank 2'},
    {name: 'Travis Hunter', college: 'Colorado', pos: 'CB', rank: 'Rank 3'},
    {name: 'Tetairoa McMillan', college: 'Arizona', pos: 'WR', rank: 'Rank 4'},
    {name: 'Malaki Starks', college: 'Georgia', pos: 'S', rank: 'Rank 5'},
    {name: 'Benjamin Morrison', college: 'Notre Dame', pos: 'CB', rank: 'Rank 6'}
    ]
const numOfButtons = playersArray.length;

for (let i = 0; i < numOfButtons; i++) {
    const currPlayer = playersArray[i];
    const button = document.createElement('button');
    const img = document.createElement('img');
    const hr = document.createElement('hr');
    const playerBin = document.createElement('div');
    playerBin.className = 'playerBin';

    img.className = 'playerCollegeImg';
    img.src = "collegeLogos/" + currPlayer.college + ".png"

    button.className = 'playersButton';
    button.textContent = currPlayer.pos + ": " + currPlayer.name + " -- " + currPlayer.rank;

    playerBin.appendChild(img);
    playerBin.appendChild(button);

    // Append the player container to the draft container
    draftCon.appendChild(playerBin);
    draftCon.appendChild(hr);
}